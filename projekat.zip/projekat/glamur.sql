-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 05, 2018 at 07:08 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glamur`
--
CREATE DATABASE IF NOT EXISTS `glamur` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `glamur`;

-- --------------------------------------------------------

--
-- Table structure for table `narudzbine`
--

DROP TABLE IF EXISTS `narudzbine`;
CREATE TABLE IF NOT EXISTS `narudzbine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adresa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telefon` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `proizvod_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `narudzbine`
--

INSERT INTO `narudzbine` (`id`, `ime`, `adresa`, `telefon`, `proizvod_id`) VALUES
(6, 'Jelena Glisic', 'Raca', '31312', 2);

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

DROP TABLE IF EXISTS `proizvodi`;
CREATE TABLE IF NOT EXISTS `proizvodi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opis` text COLLATE utf8_unicode_ci NOT NULL,
  `cena` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `kategorija` tinyint(4) NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`id`, `ime`, `opis`, `cena`, `kategorija`, `link`) VALUES
(3, 'D&G', 'MeÄ‘u parfemima sa potpisom Dolce & Gabbana koje moÅ¾ete pronaÄ‡i u Glamur parfimerijama, Light blue je  najsveÅ¾iji i najÅ¾ivahniji, neodoljiv kao i radost Å¾ivljenja. Pun je iznenaÄ‘enja i mirisnog \"kolorita\". Å½enstven i odluÄan. Dubok i istinit.\r\nâ€¢	Gornje note: sicilijanski limun, zelena jabuka, divlji zumbul\r\nâ€¢	Srednje note: jasmin, bambus, ruÅ¾a\r\nâ€¢	Donje note: kedar, Ä‡ilibar, limun\r\n', '7290', 1, 'parfemdg2.jpg'),
(2, 'Collistar preparati', 'Dezodorans produÅ¾ene sveÅ¾ine na bazi biljnih ekstrakata. Njegova specifiÄna formula obezbeÄ‘uje dugotrajnu sveÅ¾inu i negu neÅ¾ne koÅ¾e pazuha, dok esencijalna ulja i mediteranski ekstrakti pruÅ¾aju neÅ¾an i zavodljiv miris. Ne sadrÅ¾i aluminijumove soli.<br><br>\r\nSastav<br>\r\nesencijalna ulja i aromatiÄni ekstrakti mandarine, grejpfruta i vinove loze.\r\n', '1374', 2, 'bioterm2.jpg'),
(4, 'Gucci Guilty Intense', 'Gucci Guilty Intense. PreviÅ¡e nikad nije dovoljno za Gucci Guilty Å¾enu koja se usuÄ‘uje da se prepusti joÅ¡ moÄ‡nijim oseÄ‡ajima.', '8490', 1, 'parfemguci1.jpg'),
(5, 'Flora Garden', 'Kolekcija Flora Garden je buket mirisa inspirisan slavnom Flora Å¡arom modne kuÄ‡e Gucci. Kolekcija izraÅ¾ava svu ljupkost Flora Å¾ene, Å¡armantne, romantiÄne i optimistiÄne. Flora Garden slavi viÅ¡estranost kojom Gucci Å¾ena izraÅ¾ava svoju liÄnost. \r\nNoseÄ‡i jedan od mirisa iz ove kolekcije, ona izraÅ¾ava stranu svoje liÄnosti koju odluÄi da istakne.\r\nKolekcija sadrÅ¾i pet parfema â€“ Glorious Mandarin, Generous Violet, Gracious Tuberose, Gorgeous Gardenia, Glamorous Magnolia.\r\nKao kreacija verna savrÅ¡enom cvetu gardenije, GORGEOUS GARDENIA pokazuje lakoÄ‡u prvog pupoljka i opojnu raskoÅ¡ grma u punom cvatu, da biste se oseÄ‡ale predivno Å¾enstveno.\r\n', '6853', 1, 'parfemguci2.jpg'),
(6, 'Dior', 'Äavolska senzualnost. Ekstremna provokacija.\r\nMAGIÄŒAN â€“ DRAMATIÄŒAN â€“ INTRIGANTAN â€“ HIPNOTIÅ UÄ†I\r\nOrijentalna heroina je zavodljiva i intrigantna. Ona zraÄi i opÄinjava.\r\nNjeno ponaÅ¡anje je dramatiÄno. Za nju, Å¾ivot je igra.\r\n', '5990', 1, 'parfemdior1.jpg'),
(7, 'DiorAddiet', 'Samo za najsnaÅ¾nije Å¾ene. Imajte senzaciju mora, planine, reke, kiÅ¡e i sunca. Probajte!', '8563', 1, 'parfemdior2.jpg'),
(8, 'Felicita', 'Dezodorans produÅ¾ene sveÅ¾ine na bazi biljnih ekstrakata. Njegova specifiÄna formula obezbeÄ‘uje dugotrajnu sveÅ¾inu i negu neÅ¾ne koÅ¾e pazuha, dok esencijalna ulja i mediteranski ekstrakti pruÅ¾aju neÅ¾an i zavodljiv miris. Ne sadrÅ¾i aluminijumove soli.\r\nSastav\r\nesencijalna ulja i aromatiÄni ekstrakti mandarine, grejpfruta i vinove loze.\r\n', '1374', 2, 'Colistar1.jpg'),
(9, 'sprej za zaÅ¡titu od sunca', 'Lagan, proziran i osveÅ¾avajuÄ‡i sprej za zaÅ¡titu od sunca. Brzo se upija i koÅ¾u Äini neÅ¾nom i gipkom. Idealan tokom sportskih aktivnosti na plaÅ¾i, moÅ¾e da se nanosi na lice, telo i kosu. Namenjen svim tipovima koÅ¾e, hidrira i hrani koÅ¾u, Äini je elastiÄnom i podstiÄe dobijanje preplanule nijanse. PraktiÄno pakovanje omoguÄ‡uje upotrebu u svakom poloÅ¾aju, zbog Äega lako dopire do svih delova tela, Äak i najnepristupaÄnijih (leÄ‘a i zadnja strana nogu). PromuÄ‡kajte pre upotrebe i sa udaljenosti od oko 20cm prskajte delove tela izloÅ¾ene suncu, izbegavajuÄ‡i oÄi i iritirane delove koÅ¾e. Ponovite ukoliko se duÅ¾e sunÄate, posle kupanja ili kad osetite potrebu.\r\nSastav\r\nulja jojobe i biljke Tamanu, vitamin E, oleoyl tyrosine, UV-A i UV-B filteri.\r\n', '2334', 2, 'Colistar2.jpg'),
(10, 'Collistar flasteri', 'Potpuna revolucija u svetu tretmana za telo: tehnoloÅ¡ki inovativan â€žÅ¡okâ€œ tretman u vidu flastera koji pomaÅ¾u u smanjenju lokalizovanih masnih naslaga i preoblikovanju stomaka i bokova. Preoblikuju za samo 4 nedelje, suÅ¾avaju struk, zateÅ¾u i uÄvrÅ¡Ä‡uju. Kada se nanese na tretiranu povrÅ¡inu, flaster tokom 8 sati postepeno otpuÅ¡ta aktivne sastojke: Caffeine, Garcinia Cambogia i Ginkgo Biloba, pruÅ¾ajuÄ‡i intenzivni efekat oblikovanja i uÄvrÅ¡Ä‡ivanja tela. Izuzetno praktiÄan za upotrebu i prijatan za noÅ¡enje, u samo nekoliko koraka se nanosi i savrÅ¡eno prijanja na koÅ¾u, stvarajuÄ‡i oseÄ‡aj â€˜second skinâ€™. Nevidljiv je ispod odeÄ‡e i moÅ¾e se ostaviti da deluje tokom cele noÄ‡i ili tokom uobiÄajenih dnevnih aktivnosti. Pakovanje sadrÅ¾i koliÄinu za 1-meseÄni tretman (8 komada za jednokratnu upotrebu). Mogu se koristiti tokom cele godine, a savrÅ¡eni su pred poÄetak bikini-sezone. Idelni su za sve tipove koÅ¾e, ali ih nemojte koristiti ukoliko postoje trenutne iritacije ili tokom izuzetnog fiziÄkog napora. Namenjeni su samo predelu stomaka i bokova. Izbegavajte kontakt sa oÄima i drÅ¾ite ih van domaÅ¡aja dece. KliniÄki dokazana efikasnost.\r\n\r\nSastav:\r\nkambodÅ¾anska garsinija (limfna drenaÅ¾a), ginko biloba (zateÅ¾e i uÄvrÅ¡Ä‡uje), kofein (lipolitiÄko dejstvo), termoaktivni sastojci (podstiÄu mikrocirkulaciju)\r\n\r\nUpotreba:\r\nZa maksimalan uÄinak i savrÅ¡en stomak i bokove, flastere koristite 2 puta nedeljno, tako Å¡to Ä‡ete ih naneti na Äistu i potpuno suvu koÅ¾u, i ostaviti da deluju tokom 8 sati. Prilikom skidanja, paÅ¾ljivo odlepite ivicu i kratkim i brzim pokretom skinite ceo flaster (poput klasiÄnog flastera), bacite ga i operite ruke. Tokom noÅ¡enja, a u zavisnosti od osetljivosti koÅ¾e, moÅ¾ete osetiti blago peckanje i toplotu koji su posledica ubrzanja mikrocirkulacije\r\n', '4990', 2, 'Colistar3.jpg'),
(11, 'Milky Lovers', 'Milky Lovers kolekcija, buter krema, bogata krema koju koÅ¾a brzo upija. Prijatna je na dodir, meka i lagana, i kao takva predstavlja pravi koncentrat dobrostanja. Posebna paÅ¾nja je posveÄ‡ena formulama za Milk Lovers kolekciju, sa naglaskom na aktivnim sastojcima koji potiÄu iz prirode. MekoÄ‡a, prefinjenost, Äistota, uz besprekornu belu boju koja simbolizuje zdravlje. Mleko je glavni sastojak od presudne vaÅ¾nosti za koÅ¾u, sa prepoznatljivim svojstvima koja utiÄu na njenu lepotu: hidratantno je i hranljivo, i istovremeno smiruje koÅ¾u. Iako se prvenstveno koristi u prehrambene svrhe, mleko je ovde interpretirano od sastojaka potpuno biljnog porekla: badem, ovas i pirinaÄ. Mleko je uÅ¾itak za vaÅ¡a Äula, bogato je i kremasto na vaÅ¡oj koÅ¾i, i ima oÄaravajuÄ‡i i prijatan miris. Bez parabena, bez silikona, bez vazelina, bez alkohola, bez boja.\r\nOVSENO MLEKO hrani i namenjeno je suvoj koÅ¾i tela. Ovas je biljka koja uspeva Äak i u najsurovijim klimatskim uslovima severne Evrope, dok kaÅ¡a spravljena od nje ispunjava dugotrajnim oseÄ‡ajem energije. Mleko dobijeno iz ove Å¾itarice je bogato lipidima, lecitinom, proteinima, skrobom i mineralima (kalijum, kalcijum i mangan). ZahvaljujuÄ‡i izuzetnim hranljivim i revitalizujuÄ‡im svojstvima, naroÄito je pogodna za suvu koÅ¾u.\r\n', '1890', 2, 'pura2.jpg'),
(12, 'Pirincano mleko', 'Milky Lovers kolekcija, mleko za negu tela, belo i teÄno poput pravog mleka, obavija koÅ¾u mekom i laganom penom i Äisti je na najneÅ¾niji moguÄ‡i naÄin. Posebna paÅ¾nja je posveÄ‡ena formulama za Milk Lovers kolekciju, sa naglaskom na aktivnim sastojcima koji potiÄu iz prirode. MekoÄ‡a, prefinjenost, Äistota, uz besprekornu belu boju koja simbolizuje zdravlje. Mleko je glavni sastojak od presudne vaÅ¾nosti za koÅ¾u, sa prepoznatljivim svojstvima koja utiÄu na njenu lepotu: hidratantno je i hranljivo, i istovremeno smiruje koÅ¾u. Iako se prvenstveno koristi u prehrambene svrhe, mleko je ovde interpretirano od sastojaka potpuno biljnog porekla: badem, ovas i pirinaÄ. Mleko je uÅ¾itak za vaÅ¡a Äula, bogato je i kremasto na vaÅ¡oj koÅ¾i, i ima oÄaravajuÄ‡i i prijatan miris. Bez parabena, bez silikona, bez vazelina, bez alkohola, bez boja.\r\nPIRINÄŒANO MLEKO smiruje i namenjeno je osetljivoj koÅ¾i tela. PirinaÄ je jedna od najÄeÅ¡Ä‡e uzgajanih Å¾itarica u svetu. Kao bogat izvor energije, koristi se od davnina u kineskoj medicini za ublaÅ¾avanje stresa i jaÄanje. Mleko dobijeno iz ove Å¾itarice je bogato skrobom, masnim kiselinama (linoleinska i oleinska) i mineralima (gvoÅ¾Ä‘e, fosfor i magnezijum). ZahvaljujuÄ‡i hranljivim i omekÅ¡avajuÄ‡im svojstvima, deluje regenerativno na umornu i osetljivu koÅ¾u.\r\n', '1790', 2, 'pura3.jpg'),
(13, 'BLUE THERAPY EYE', 'Tokom zimskog perioda naÅ¡a koÅ¾a je izloÅ¾ena hladnom zimskom vazduhu, ali i suvom, toplom vazduhu karakteristiÄnom za zatvorene prostorije. I upravo zbog tog dualnog temperaturnog uticaja u najhladnijim mesecima posebnu paÅ¾nju moramo posvetiti nezi naÅ¡ih ruku i lica jer su oni najviÅ¡e izloÅ¾eni spoljaÅ¡njim uticajim.\r\nKrema za oko oÄiju protiv prvih znakova starenja.', '1385', 3, 'bioterm1.jpg'),
(14, 'Krema Bioterm', 'UzevÅ¡i u obzir Äinjenicu da se zaÅ¡tiÄ‡ena koÅ¾a sama obnavlja , Biotherm je razvio svoju prvu kremu s viÅ¡estrukom zaÅ¡titom i delovanjem protiv znakova starenja. Sada jedna krema pruÅ¾a viÅ¡estruku zaÅ¡titu i poboljÅ¡ava obnovu koÅ¾e. S obzirom na dokazano delovanje protiv zagaÄ‘enja  i izloÅ¾enosti UV zracima, kao i na poboljÅ¡ano delovanje na bore, tamne mrlje i gubitak Ävrstine , nikada nije kasno da svojoj koÅ¾i pruÅ¾ite pravu zaÅ¡titu na svakodnevnoj osnovi. Biotherm po prvi put predstavlja formulu koja pruÅ¾a istovremenu zaÅ¡titu od kljuÄnih spoljnih agresora: dugih UVA zraka, UVA i UVB zraka i zagaÄ‘enja, u kombinaciji sa sastojcima koji revitalizuju koÅ¾u.', '8190', 3, 'bioterm3.jpg'),
(15, 'Krema u ulju', 'Biotherm kreira kremu u ulju, kao naprevljenu od meda, intenzivno hranljivu, a neverovatno sveÅ¾u i laganu, zahvaljujuÄ‡i njenoj stapajuÄ‡oj i transformiÅ¡uÄ‡oj teksturi. Jedinstvena kombinacija morskog Å¡eÄ‡era , sulfatnog Å¡eÄ‡era koji luÄe morski mikroorganizmi, poznatog po regenerativnim svojstvima, i kreme u ulju, kao stvorene od meda za intenzivnu negu koÅ¾e. PruÅ¾a trenutan oseÄ‡aj intenzivne hidratacije. Dan za danom, linije su zaglaÄ‘ene,ten izgleda oÅ¾ivljeno, a koÅ¾i je vraÄ‡ena jedrost.', '8290', 3, 'bioterm4.jpg'),
(16, 'Gatulin', 'Koncentrovani serum sa neverovatnim uÄinkom popunjavanja bora. Redovnom upotrebom, veÄ‡ nakon prve nedelje  koÅ¾a postaje vidno podmlaÄ‘ena i bez bora. Gatulin (patentirani sastojak) ublaÅ¾ava mikrokontrakcije lica usled kojih nastaju mimiÄne bore, na taj naÄin spreÄava njihovo nastajanje i uklanja veÄ‡ postojeÄ‡e. Naneti i umasirati do potpunog upijanja a nakon toga naneti regularnu kremu za vas tip koÅ¾e. DermatoloÅ¡ki i oftalmoloÅ¡ki testiran proizvod.', '1950', 3, 'dermolab1.jpg'),
(17, 'Dermolab balzam', 'Bogati kremasti balzam posebno namenjen skidanju i najotpornije Å¡minke sa lica. PreporuÄuje se svim tipovima koÅ¾e, obezbeÄ‘ujuÄ‡i dodatnu hidrataciju i energiju. Detaljno uklanja sve neÄistoÄ‡e sa lica i koÅ¾u Äini neÅ¾nom i barÅ¡unastom. Umasirajte kremu u koÅ¾u i uklonite vlaÅ¾nom vaticom ili isperite mlakom vodom. Ne sadrÅ¾i paraben, niti alkohol. DermatoloÅ¡ki i oftalmoloÅ¡ki testiran proizvod.', '1953', 3, 'dermolab2.jpg'),
(18, 'Gel za skidanje Å¡minkanje', 'NeÅ¾no ulje za ÄiÅ¡Ä‡enje, efikasno otklanja Å¡minku i druge neÄistoÄ‡e sa lica. Nano Vektor Hijaluronske KiselineomoguÄ‡ava snaÅ¾no hidriranje koÅ¾e. Jojoba ulje pomaÅ¾e da se normalizuje prirodni PH faktor i koÅ¾i vraÄ‡a elastiÄnost i mekoÄ‡u. Ekstrakt soje bogat vitaminom E bori se protiv slobodnih radikala. DermatoloÅ¡ki i oftalmoloÅ¡ki testiran proizvod.', '952', 3, 'dermolab3.jpg');
--
-- Database: `horoskop`
--
CREATE DATABASE IF NOT EXISTS `horoskop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `horoskop`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `vest_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `nickname`, `comment`, `vest_id`) VALUES
(12, 'sd', 'Najveca glupost moguca', 10);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sign` tinyint(4) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `datetime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `sign`, `description`, `datetime`) VALUES
(5, 2, 'Danas će vam u poslovnom segmentu trebati velika pomoć i podrška od strane kolega, pa se potrudite da ih zamolite za uslugu, jer obaveze koje imate nećete moći sami da završite. Partner je u jako dobrom raspoloženju i spreman je da vam oprosti i neke sitnije greškice iz prethodnih dana. ', '2018-02-20'),
(6, 9, 'Zabrinuti ste kako će se na dalje odvijati situacije po jednom pitanju koje vam je jako bitno. Nemate razloga za uznemirenost, sve će se rešiti brže nego što ste to mislili. Sa voljenom osobom porazgovarajte otvoreno, jer ćete na taj način prevazići neku sitniju problematiku koja smeta vašem odnosu. ', '2018-02-20'),
(7, 1, 'U ovu sedmicu ulazite sa tačnom konjukcijom Marsa koji vlada vašim znakom I Jupitera u polju strasti, kriza I promena. Na suprotni pol delujete maltene pa opčinjavajuće, pa nije ni čudo što vaš emotivni ili bračni partner počinje da se oseća nesigurno. Sumnje se kod druge strane mogu javljati sve češće I češće, a naročito u drugom delu sedmice, kada može doći I do prvih rasprava I varnica između vas dvoje. Ukoliko ste ušli u neku tajnu priču, stoji da je trenutno dobro skrivate, ali nemojte se zanositi – partner oseća da se nešto dešava I da nešto nije u redu. Ukoliko ste solo, ovo je savršena sedmica da otpočnete novu “love story”. Privlačite poglede I teško vam je odoleti…. ', '2018-02-20'),
(8, 1, 'Polje karijere je I dalje jako potencirano, posebno što u njega tokom ove nedelje ulazi I planeta Merkur, što će doneti jaču komunikaciju, proširenje već postojećih dogovora, ali I potpuno nove saradnike. Ovnovi će se žestoko aktivirati, jer osećaju da su u periodu koji im može doneti mnogo po pitanju posla. Preporuka je da se I oni koji su nezaposleni pokrenu, jer će do pravih prilika doći lakše nego inače. Nekima od vas može pasti na pamet I pokretanje posla sa prijateljem ili rođakom. \r\n', '2018-02-20'),
(9, 10, 'Dobijate od nekog čvrste garancije da ćete uspeti po jednom poslovnom pitanju. Prosto ne znate smete li da se radujete unapred ili da čekate da se ovo obećanje i ispuni. Na poslovnom okupljanju primećujete osobu koja vam jako privlači pažnju. Pokušajte da ostvarite jaču komunikaciju sa njom. \r\n', '2018-02-20'),
(10, 3, 'Zaljubicete se. Spremite se!', '2018-07-02');
--
-- Database: `ispit`
--
CREATE DATABASE IF NOT EXISTS `ispit` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ispit`;

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

DROP TABLE IF EXISTS `korisnici`;
CREATE TABLE IF NOT EXISTS `korisnici` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnicko` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ime` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prezime` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slika` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pol` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sifra` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `info` text COLLATE utf8_unicode_ci NOT NULL,
  `datum` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `korisnicko`, `ime`, `prezime`, `slika`, `pol`, `sifra`, `email`, `info`, `datum`) VALUES
(1, 'Marko', 'Marko', 'Nedovic', 'http://slika.nezavisne.rs/2016/03/750x450/20160301142849_356924.jpg', 'Muski', '12345', 'markoned@gmail.com', 'kjdsgfkshjnogf.li', '1980-03-03'),
(11, 'Anja123', 'Anja', 'Zivkovic', 'http://slike.djecaci.net/kolumne/zene/1zene10.jpg', 'Zenski', '123', 'anjazivkovic3@gmail.com', 'asgf,hasgf.w', '1996-01-23'),
(12, 'NikolaD', 'Nikola', 'Simic', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSrx-J5iLSYuPEVnxJ6gbd6RAU0DQzNdR_6-LVQ1QJyCMhSp3reCXxY4ko6', 'Muski', '123', 'hnikola@hdo.com', 'gkhdkugh;', '1997-02-15'),
(13, 'Lazar123', 'Lazar', 'Radovic', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyd9aseYVb1OjHxpjS0JEzpNQ9oNMm-rX3qQI78wMaEMivyLs7JirWjTkE', 'Muski', 'asdf', 'lazar@ghfdleisk.com', 'hdgflhlaoiehgoi', '1970-03-05'),
(14, 'Peraaa', 'Petar', 'Filipovic', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9sV6tck0aL0ADZmf-pvD9RX_AZ_D6Mzl6PZNQw8TCPgqwGBhOu6cFlg1n', 'Muski', 'ghfy', 'peraa@gmail.com', 'gkdfhoigh', '1996-04-04'),
(15, 'Filip123', 'Filip', 'Zivkovic', 'http://www.zvornikdanas.com/2017/12/u-ovim-zemljama-zive-najzgodniji-muskarci/', 'Muski', 'dfbvhjs', 'filip12@gmail.com', 'ghfdklugholawrh', '1988-07-07'),
(16, 'Ana2436', 'Ana', 'Nedic', 'https://images.pexels.com/photos/264172/pexels-photo-264172.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260', 'Zenski', 'hfds', 'anate@gjhns.com', 'dsgfs', '1984-02-03'),
(17, 'Jovana', 'Jovana', 'Lukic', 'https://www.cafe.ba/wp-content/uploads/2017/05/lijepe_%C5%BEene_1_.jpg', 'Zenski', 'dksk', 'hdsw@bgdhj.com', 'rtur', '1988-03-03'),
(18, 'Jelenagfe', 'Jelena', 'Savic', 'https://www.zenskimagazin.rs/chest/timg/1489022232_sta-zene-sirom-sveta-rade-da-bi-bile-atraktivne%20(8).jpg', 'Zenski', 'sdhjgfj', 'hdjugf@gsd.com', 'gfhr', '1988-05-05'),
(19, 'Natasa243', 'Natasa', 'Vidic', 'https://www.mojevrijeme.hr/magazin/wp-content/uploads/2014/12/zena-punija-657x360.jpg', 'Zenski', '25463', 'hdjdnb@ghdsbd.com', 'dgydrt', '1988-07-07'),
(21, 'Milosav', 'Milosav', 'Milivojevic', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUFqGjiDzXvEnBH8EchUQduxqBhbDCqqUjBn5IIDaJY63Glpeh2w', 'Muski', 'milosav', 'milosav@gmail.com', 'Upoznajmo se pa sami ocenite.', '1985-06-27');
--
-- Database: `proba`
--
CREATE DATABASE IF NOT EXISTS `proba` DEFAULT CHARACTER SET utf8 COLLATE utf8_croatian_ci;
USE `proba`;

-- --------------------------------------------------------

--
-- Table structure for table `a`
--

DROP TABLE IF EXISTS `a`;
CREATE TABLE IF NOT EXISTS `a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(50) COLLATE utf8_croatian_ci NOT NULL,
  `opis` text COLLATE utf8_croatian_ci NOT NULL,
  `cena` varchar(30) COLLATE utf8_croatian_ci NOT NULL,
  `kategorija` tinyint(4) NOT NULL,
  `link` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b`
--

DROP TABLE IF EXISTS `b`;
CREATE TABLE IF NOT EXISTS `b` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `adresa` varchar(255) COLLATE utf8_croatian_ci NOT NULL,
  `telefon` varchar(30) COLLATE utf8_croatian_ci NOT NULL,
  `proizvodi_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;
--
-- Database: `radnik`
--
CREATE DATABASE IF NOT EXISTS `radnik` DEFAULT CHARACTER SET utf8 COLLATE utf8_croatian_ci;
USE `radnik`;

-- --------------------------------------------------------

--
-- Table structure for table `radik`
--

DROP TABLE IF EXISTS `radik`;
CREATE TABLE IF NOT EXISTS `radik` (
  `ime` text COLLATE utf8_croatian_ci NOT NULL,
  `prezime` text COLLATE utf8_croatian_ci NOT NULL,
  `adresa` text COLLATE utf8_croatian_ci NOT NULL,
  `id radnika` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `radik`
--

INSERT INTO `radik` (`ime`, `prezime`, `adresa`, `id radnika`) VALUES
('milan\r\nboba\r\nSonja\r\nmaja\r\nvesna', 'vdsv\r\nvfdv\r\nbdfbfd\r\ndsds\r\nbvdfvbf', 'vsvd\r\nvsfdf\r\nvrsdfsdv\r\nvdfds\r\nvsdds\r\n', 556655);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
