<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>GLAMUR</title>
 <link rel="stylesheet" type="text/css" href="/projekat/izgled.css" />
</head>

<body>

  <img src="/slike/prodavnica.png";">
  
<center>
<a href="/projekat/index.php">
 </center>
<center>
<div id="navigacija">
	<a class="active" href="/projekat/index.php"><b>O nama</b></a>
  <a href="/projekat/index.php"><b>Parfemi</b></a>
  <a href="/projekat/index.php"><b>Sminka</b></a>
  <a href="/projekat/index.php"><b>Nega lica</b></a>
  <a href="/projekat/index.php"><b>Opsti uslovi kupovine</b></a>
  <a href="/projekat/index.php"><b>Login</b></a>


</div>

<center><div class="futer" id="futer">

<hr>
   <div class="klasa">
     <br><center><i>
     Parfimerija Glamur <br>
      
      </i></center>
      </div>
 <br>
  <p1><i><center>KONTAKT 034/958-942&nbsp;|&nbsp;PRODAJNA MESTA: KRAGUJEVAC, Zmaj Jovina 17&nbsp;|&nbsp;
  <a href="//localhost/projekat/login/login.php"><font color="red">Login</font></a></i></p1>
 </div></center>
</div>

</body>
</html>